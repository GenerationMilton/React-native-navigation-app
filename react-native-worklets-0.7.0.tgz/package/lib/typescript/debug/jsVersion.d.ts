/**
 * We hardcode the version of Worklets here in order to compare it with the
 * version used to build the native part of the library in runtime. Remember to
 * keep this in sync with the version declared in `package.json`
 */
export declare const jsVersion = "0.7.0";
//# sourceMappingURL=jsVersion.d.ts.map